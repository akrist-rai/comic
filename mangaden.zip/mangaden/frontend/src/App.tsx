import Library from './pages/Library';

// App is the root of the component tree.
// Right now it just renders Library.
// Phase 5 (Routing) will replace this with <RouterProvider> and route definitions.

function App() {
  return (
    <div className="app">
      <Library />
    </div>
  );
}

export default App;
