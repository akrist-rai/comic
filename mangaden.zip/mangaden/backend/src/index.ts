import Koa from 'koa';
import { koaBody } from 'koa-body';
import { cors } from './middleware/cors';
import { mangaRouter } from './routes/manga';

const app  = new Koa();
const PORT = 3001;

app.use(cors);
app.use(koaBody());
app.use(mangaRouter.routes());
app.use(mangaRouter.allowedMethods());

app.listen(PORT, () => {
  console.log(`MangaDen API  →  http://localhost:${PORT}`);
});
